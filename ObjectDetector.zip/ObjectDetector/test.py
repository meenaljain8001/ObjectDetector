from keras.models import load_model
model = load_model('object.h5')
print(model.summary())
