#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun May  5 15:45:56 2019

@author: meenal
"""

from flask import Flask,request,url_for,render_template
import os
import cv2
import numpy as np
from keras.models import load_model

path = 'image'
obj = Flask(__name__)
@obj.route('/')
def intro():
    return render_template('data.html')
@obj.route('/select',methods = ['POST'])
def start():
    if not os.path.isdir(path):
        os.mkdir(path)
    for img in request.files.getlist('value'):
        fname = img.filename
        img.save(str(path)+'/'+str(fname))
        img = cv2.imread(str(path)+'/'+str(fname))
        img = cv2.resize(img,(32,32))
        img = np.expand_dims(img,axis=0)
        model = load_model('object.h5')
        pred = model.predict(img)
        pred = int(np.argmax(pred))
        

    return render_template("file1.html", output = pred)

obj.run(debug=True)



